#ifndef __ULTRASONICCTROL_H_
#define __ULTRASONICCTROL_H_

extern volatile unsigned int distance_cm;//��ǰ����
extern volatile unsigned int distance_cm2;//��ǰ����
void UltraSoundInit(void);
void GetDistanceDelay(void);
void GetDistanceDelay2(void);
void Distance(void);
void Distance2(void);
void LCD12864WriteDistance(unsigned int distance);
#endif
