#ifndef __LCD1602_H_
#define __LCD1602_H_


void LCD1602Init(void);
void LCD1602WriteCommand(char comm);
void LCD1602WriteSpeed(unsigned char fl,unsigned char fr,int line);
void LCD1602Writemod(char comm);
extern long long dis_l;
extern long long dis_r;
#endif
